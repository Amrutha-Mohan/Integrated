package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.beans.ScoreBoard;
import com.beans.TrainingDetail;
import com.dao.CredentialDao;
import com.dao.ProfileDao;

/**
 * Servlet implementation class ProfileController
 */
@WebServlet("/ProfileController")
public class ProfileController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	private ProfileDao prfDao;

	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProfileController() {
        super();
    }
    
    @Override
	public void init() throws ServletException {
		super.init();
		prfDao=new ProfileDao();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		getMyProfile(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	private void getMyProfile(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session = request.getSession(false);
		String bensyl_Id=(String)session.getAttribute("uname");
		List<TrainingDetail> trnList=new ArrayList<TrainingDetail>();
		List<YPWP> ypwpList=new ArrayList<YPWP>();
		
		try {
			
			trnList=prfDao.getMyProfile(bensyl_Id);
			ypwpList=prfDao.getYPWP(bensyl_Id);
			request.setAttribute("trnList", trnList);
			request.setAttribute("ypwpList", ypwpList);
			RequestDispatcher dispatcher=request.getRequestDispatcher("user_profile.jsp");
			dispatcher.forward(request, response);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
