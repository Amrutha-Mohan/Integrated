package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.dao.UploadDao;

/**
 * Servlet implementation class UploadController
 */
@WebServlet("/UploadController")
public class UploadController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private UploadDao objUpload;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadController() {
        super();
    }
    
    @Override
	public void init() throws ServletException {
		super.init();
		objUpload=new UploadDao();
	}
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		
		
		String cmd=request.getParameter("cmd");
		if(cmd.equals("Trainings")){
			readFromFile(request,response);
		}
		else if(cmd.equals("YPWP")){
			readFromYPWP(request,response);
		}
	}

	private void readFromFile(HttpServletRequest request,HttpServletResponse response) {
		
		int result=0;
		String trn_year=request.getParameter("trn_year");
		String fileName=request.getParameter("excel");
		try {
			result=objUpload.uploadExcel(trn_year,fileName);
			if(result==1){
				request.setAttribute("ErrUpload","Uploaded successfully");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_upload.jsp");
				dispatcher.forward(request, response);
			}
		}catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	private void readFromYPWP(HttpServletRequest request,HttpServletResponse response) {
		
		int result=0;
		String trn_year=request.getParameter("trn_year");
		String fileName=request.getParameter("YPWPExcel");
		try {
			
			result=objUpload.uploadYPWP(trn_year,fileName);
			if(result==1){
				request.setAttribute("ErrUpload","Uploaded successfully");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_upload.jsp");
				dispatcher.forward(request, response);
			}
		}catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

}
