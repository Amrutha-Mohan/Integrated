package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.beans.Employee;
import com.dao.AdminDao;
import com.dao.EmpUpdationDao;

/**
 * Servlet implementation class EmpUpdationController
 */
@WebServlet("/EmpUpdationController")
public class EmpUpdationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private EmpUpdationDao empDao;

	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmpUpdationController() {
        super();
    }
    
    @Override
	public void init() throws ServletException {
		super.init();
		empDao=new EmpUpdationDao();
		
	}


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		String action=request.getParameter("action");
		if(action.equals("UPDATE")){
			updateEmployee(request,response);
		}
		else if(action.equals("DELETE")){
			deleteEmployee(request,response);
		}	
		
	}	

	private void deleteEmployee(HttpServletRequest request, HttpServletResponse response) {
		
		String bensyl_Id=(request.getParameter("curID")).toUpperCase();		
		String msg="";
		try {
			PrintWriter pw=response.getWriter();
			//call dao method to delete an employee account.
			msg=empDao.deleteEmployeeDetail(bensyl_Id);
			if(msg.equals("updated")){
				request.setAttribute("updateMsg","Employee Details Deleted");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_searchEmp.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("failed")){
				request.setAttribute("updateMsg","Deletion Failed");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_searchEmp.jsp");
				dispatcher.forward(request, response);
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}

	private void updateEmployee(HttpServletRequest request, HttpServletResponse response) {
		
		String msg="";
		String bensyl_Id=(request.getParameter("curID")).toUpperCase();
		
		//set updated employee details to its object
		Employee objEmp=new Employee();
		objEmp.setBensel_id((request.getParameter("Bensylid")).toUpperCase());
		objEmp.setEmp_name(request.getParameter("name"));
		objEmp.setEmp_email(request.getParameter("email"));
		try {
			
			PrintWriter pw=response.getWriter();
			//call dao method to to update details of an employee
			msg=empDao.updateEmployeeDetail(bensyl_Id,objEmp);
			if(msg.equals("exist")){
				request.setAttribute("updateMsg","Changed Bensyl ID is already in use by another employee");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_searchEmp.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("updated")){
				request.setAttribute("updateMsg","Details Updated Successsfully");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_searchEmp.jsp");
				dispatcher.forward(request, response);
			}
			else if(msg.equals("failed")){
				request.setAttribute("updateMsg","Updation Failed");
				RequestDispatcher dispatcher= request.getRequestDispatcher("admin_searchEmp.jsp");
				dispatcher.forward(request, response);
			}
			else{				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}

}
