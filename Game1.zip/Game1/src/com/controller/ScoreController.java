package com.controller;

import java.io.IOException;
import java.util.*;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.beans.Scores;
import com.dao.ScoreDao;

/**
 * Servlet implementation class ScoreController
 */
@WebServlet("/ScoreController")
public class ScoreController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ScoreDao scrDao;

			/*@Resource(name="gameDB")
			private DataSource dataSource;*/
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ScoreController() {
        super();
    }
    
    @Override
	public void init() throws ServletException {
		super.init();
				//scrDao=new ScoreDao(dataSource);
		scrDao=new ScoreDao();
	}
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		getScoreBoard(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}	

	private void getScoreBoard(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session = request.getSession(false);
		String bensyl_Id=(String)session.getAttribute("uname");
		List<Scores> scoreList=new ArrayList<Scores>();
		scoreList=scrDao.getScoreBoard();
		request.setAttribute("scrList", scoreList);
		request.setAttribute("ID", bensyl_Id);
		RequestDispatcher dispatcher=request.getRequestDispatcher("user_scoreboard.jsp");
		try {
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
