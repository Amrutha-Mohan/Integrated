package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.sql.DataSource;

import com.beans.Employee;
import com.dbcon.DBConnection;
import com.listeners.CredentialListener;


public class EmployeeDao implements CredentialListener{

	public EmployeeDao() {
		super();
	}

	public int addEmployee(Employee employee) throws SQLException{
		
		PreparedStatement pstmt=null,pstmt2=null,pstmt3=null,pstmt4=null;
		ResultSet rs=null,rs2=null;
		int result=0;
		String date="";
		DBConnection dbCon=new DBConnection();
		
		String sql4="select bensel_id from gmf_employee where upper(bensel_id)=?";
		String sql="insert into gmf_employee(bensel_id,emp_name,emp_email,status) values(?,?,?,?)";
		String sql2="insert into gmf_scoreboard values(?,?,?,?,?,?,?,?)";
		String sql3="select to_char(sysdate, 'YYYY') from dual";
		
		try {
			
			pstmt4=dbCon.getStatement(sql4);
			pstmt4.setString(1, employee.getBensel_id());
			rs2=pstmt4.executeQuery();
			if(rs2.next()){
				return -1;
			}
			else{	
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, employee.getBensel_id());
				pstmt.setString(2, employee.getEmp_name());
				pstmt.setString(3, employee.getEmp_email());
				pstmt.setString(5, employee.getStatus());
				result=pstmt.executeUpdate();
						
				pstmt3=dbCon.getStatement(sql3);
				rs=pstmt3.executeQuery();
				if(rs.next()){
					date=rs.getString(1);
				}
						
				pstmt2=dbCon.getStatement(sql2);
				pstmt2.setString(1, employee.getBensel_id());
				pstmt2.setString(2, date);
				pstmt2.setDouble(3, 0);
				pstmt2.setInt(4, 0);
				pstmt2.setInt(5, 0);
				pstmt2.setInt(6, 0);
				pstmt2.setInt(7, 0);
				pstmt2.setInt(8, 0);
				result=pstmt2.executeUpdate();
			}					
					
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {

			dbCon.closeCon();			
			if(pstmt!=null){
				pstmt.close();
			}
			if(pstmt2!=null){
				pstmt2.close();
			}
			if(pstmt3!=null){
				pstmt3.close();
			}
			if(pstmt4!=null){
				pstmt4.close();
			}
			if(rs!=null){
				rs.close();
			}
			if(rs2!=null){
				rs2.close();
			}			
		}
		return result;
	}

	@SuppressWarnings("resource")
	public String activateEmployee(Employee employee) throws SQLException {
		
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int result=0;
		String status="",msg="null";
		String sql="select status from gmf_employee where bensel_id=? and emp_email=?";
		DBConnection dbCon=new DBConnection();
		
		try {
			
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, employee.getBensel_id().toUpperCase());
			pstmt.setString(2, employee.getEmp_email());
			rs=pstmt.executeQuery();
			if(rs.next()){
				status=rs.getString("status");
				if(status.equals("Active")){
					msg="exist";
				}
				else if(status.equals("notActive")){
					
					sql="update gmf_employee set password=?,status=? where bensel_id=?";
					pstmt=dbCon.getStatement(sql);
					pstmt.setString(1, employee.getPassword());
					pstmt.setString(2, "Active");
					pstmt.setString(3, employee.getBensel_id().toUpperCase());
					result=pstmt.executeUpdate();
					if(result==1){
						msg="activated";
					}
					else{						
					}
				}
			}
			else{
				msg="NotMatch";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {

			dbCon.closeCon();
			if(pstmt!=null){
				pstmt.close();
			}
			if(rs!=null){
				rs.close();
			}
		}
		return msg;
	}

	
	//method to query an employee's details
	public Employee getEmployee(String bensyl_id) throws SQLException {
		
		String sql="";
		PreparedStatement pstmt=null;		
		ResultSet rs=null;
		DBConnection dbCon=new DBConnection();
		
		Employee objEmp=new Employee();
		sql="select bensel_id,emp_name,emp_email from gmf_employee where upper(bensel_id)=? and status <> 'deleted'";
		try {
			//get connection object from connection pool
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_id);
			rs=pstmt.executeQuery();
			if(rs.next()){
				//set employee details to employee's object
				objEmp.setBensel_id(rs.getString("bensel_id"));
				objEmp.setEmp_name(rs.getString("emp_name"));
				objEmp.setEmp_email(rs.getString("emp_email"));
			}
			else{
				objEmp.setBensel_id("null");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
			rs.close();
		}
		return objEmp;
	}

	@Override
	public int passwordCheck(Object obj) throws SQLException {
		
		PreparedStatement pstmt=null;
		ResultSet rs1=null;
		String msg="",sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();
		
		try {
			if(obj instanceof Employee){
				Employee empObj=(Employee)obj;
				sql="select password from gmf_employee where bensel_id=? and password=?";
				
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, empObj.getBensel_id());
				pstmt.setString(2, empObj.getPassword());
				rs1=pstmt.executeQuery();
				if(rs1.next()){
					result = 1;
				}
				else{
					result = -1;
				}
			}			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
			rs1.close();
		}
		return result;
	}

	@Override
	public String changePass(Object obj) throws SQLException {
				
		PreparedStatement pstmt=null;
		String msg="",sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();
		
		try {
			
			if(obj instanceof Employee){
				Employee empObj=(Employee)obj;
					sql="update gmf_employee set password=? where bensel_id=?";
					
					pstmt=dbCon.getStatement(sql);
					pstmt.setString(1, empObj.getPassword());
					pstmt.setString(2, empObj.getBensel_id());
					result=pstmt.executeUpdate();
					if(result==1){
						msg="changed";
					}
					else{
						msg="notChanged";
					}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
		}
		return msg;
	}
}
