package com.dao;

import java.sql.*;
import java.time.Year;
import java.util.*;

import com.beans.TrainingDetail;
import com.beans.YPWP;
import com.dbcon.DBConnection;

public class ProfileDao {
	
	public ProfileDao() {
		super();
	}

	public List<TrainingDetail> getMyProfile(String bensyl_Id) throws SQLException {
		
		String sql="";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		DBConnection dbCon=new DBConnection();
		
		List<TrainingDetail> trnList=new ArrayList<TrainingDetail>();
				
		try {
			int year=Year.now().getValue();
			String strYear=Integer.toString(year);
			sql="select trn_name,trn_hour,trn_date from gmf_training_detail where bensel_id=? and trn_year=?";

			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_Id);
			pstmt.setString(2, strYear);
			rs=pstmt.executeQuery();
			while(rs.next()){
				TrainingDetail objProfile=new TrainingDetail();
				objProfile.setTrn_name(rs.getString("trn_name"));
				objProfile.setTrn_hour(rs.getFloat("training_hour"));
				objProfile.setTrn_date(rs.getString("trn_date"));
				trnList.add(objProfile);
			}

			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
			rs.close();
		}
		return trnList;
	}


	public List<YPWP> getYPWP(String bensyl_Id) throws SQLException {
		
		String sql="";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		DBConnection dbCon=new DBConnection();
		List<YPWP> ypwpList=new ArrayList<YPWP>();
				
		try {
			int year=Year.now().getValue();
			String strYear=Integer.toString(year);		

			
			sql="select practice,certification,ypwp_month from gmf_ypwp where bensel_id=? and ypwp_year=?";

			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_Id);
			pstmt.setString(2, strYear);
			rs=pstmt.executeQuery();
			while(rs.next()){
				YPWP objYPWP=new YPWP();
				objYPWP.setPractice(rs.getString("practice"));
				objYPWP.setCertification(rs.getString("certification"));
				objYPWP.setYpwp_month(rs.getString("ypwp_month"));
				ypwpList.add(objYPWP);
				
			}

			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
			rs.close();
		}
		return ypwpList;
	}
	


	/*public ScoreBoard getScore(String bensyl_Id) throws SQLException {
		
		String sql="";
				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		ScoreBoard objScore=new ScoreBoard();
		DBConnection dbCon=new DBConnection();
		
		try {
			
					//con=dataSource.getConnection();
			int year=Year.now().getValue();
			String strYear=Integer.toString(year);
			sql="select hours,trn_level,badge,trophy from game_scoreboard where bensyl_id=? and trn_year=?";
					//pstmt=con.prepareStatement(sql);
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_Id);
			pstmt.setString(2, strYear);
			rs=pstmt.executeQuery();
			if(rs.next()){
				objScore.setHours(rs.getFloat("hours"));
				objScore.setTrn_level(rs.getInt("trn_level"));
				objScore.setBadge(rs.getInt("badge"));
				objScore.setTrophy(rs.getInt("trophy"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
			if(rs!=null){
				rs.close();				
			}
		}
		return objScore;
	} */
	
	
}
