package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.beans.Admin;
import com.beans.Employee;
import com.dbcon.DBConnection;
import com.listeners.CredentialListener;

public class AdminDao implements CredentialListener{

	public AdminDao() {
		super();
	}

	@Override
	public int passwordCheck(Object obj) throws SQLException {
		
		PreparedStatement pstmt=null;
		ResultSet rs1=null;
		String msg="",sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();
		
		try {
			if(obj instanceof Admin){
				Admin admObj=(Admin)obj;
				sql="select password from gmf_admin where email=? and password=?";
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, admObj.getEmail());
				pstmt.setString(2, admObj.getPassword());
				rs1=pstmt.executeQuery();
				if(rs1.next()){
					result = 1;
				}
				else{
					result = -1;
				}
			}			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
			rs1.close();
		}
		return result;		
	}

	@Override
	public String changePass(Object obj) throws SQLException {
		
		PreparedStatement pstmt=null;
		String msg="",sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();
		
		try {
			if(obj instanceof Admin){
				Admin admObj=(Admin)obj;
				sql="update gmf_admin set password=? where email=?";
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, admObj.getPassword());
				pstmt.setString(2, admObj.getEmail());
				result=pstmt.executeUpdate();
				if(result==1){
					msg="changed";
				}
				else{
					msg="notChanged";
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
		}
		return msg;
	}
	
}
