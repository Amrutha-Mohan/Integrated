package com.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.beans.Employee;
import com.dbcon.DBConnection;

public class EmpUpdationDao {
	

	public EmpUpdationDao() {
		super();
	}
	
	@SuppressWarnings("resource")
	public String updateEmployeeDetail(String bensyl_Id, Employee objEmp) throws SQLException {
		
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int result=0;
		String sql="", msg="";
		DBConnection dbCon=new DBConnection();
		
		try {			
			//check whether bensil_id is updated or not
			
			if(!(bensyl_Id.equals(objEmp.getBensel_id()))){				
				//check whether the updated bensyl_id is already belongs to someone.
				sql="select emp_name from gmf_employee where upper(bensel_id)=?";
				
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, objEmp.getBensel_id());
				rs=pstmt.executeQuery();
				if(rs.next()){
					msg="exist";
				}
				else{
					//If new Bensyl_id is not belongs to anyone then update that employee details with updated details
					sql="update gmf_employee set bensel_id=?,emp_name=?,emp_email=? where upper(bensel_id)=?";
					
					pstmt=dbCon.getStatement(sql);
					pstmt.setString(1, objEmp.getBensel_id());
					pstmt.setString(2, objEmp.getEmp_name());
					pstmt.setString(3, objEmp.getEmp_email());
					pstmt.setString(5, bensyl_Id);
					result=pstmt.executeUpdate();
					if(result==1){
						msg="updated";
					}
					else{
						msg="failed";
					}					
				}
			}
			else{				
				//if bensyl_id is not changed update other details in that bensyl_id
				sql="update gmf_employee set emp_name=?,emp_email=? where upper(bensel_id)=?";
				
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, objEmp.getEmp_name());
				pstmt.setString(2, objEmp.getEmp_email());
				pstmt.setString(3, bensyl_Id);
				result=pstmt.executeUpdate();
				if(result==1){
					msg="updated";
				}
				else{
					msg="failed";
				}				
			}			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {			
			dbCon.closeCon();
			pstmt.close();
			if(rs!=null){
				rs.close();
			}
		}
		return msg;
	}

	
	public String deleteEmployeeDetail(String bensyl_Id) throws SQLException {
		
		
		PreparedStatement pstmt=null;
		int result=0;
		String sql="", msg="";
		DBConnection dbCon=new DBConnection();
		
		try {
			//update employee status to deleted so that he can't login any more.
			sql="update gmf_employee set status='deleted' where bensel_id=?";

			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_Id);
			result=pstmt.executeUpdate();
			if(result==1){
				msg="updated";
			}
			else{
				msg="failed";
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
		}		
		return msg;
	}
}
