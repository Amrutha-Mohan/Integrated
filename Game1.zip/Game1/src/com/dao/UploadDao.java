package com.connectionDao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.Date;

import javax.sql.DataSource;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import com.dbcon.DBConnection;


public class UploadDao {

	public UploadDao() {
		super();
	}

	public int uploadExcel(String trn_year, String fileName) throws SQLException {

		Set<String> empSet;

		int result=0;
		Float hour=0.0f;
		String sql="";

		PreparedStatement pstmt=null;

		int FR=1;
		int FC = 0;
		int LC = 9;
		DBConnection dbCon=new DBConnection();


		try {
			empSet=getAllBensyl();
			deleteTables(trn_year);
			System.out.println("start uploading");

			FileInputStream fStream = new FileInputStream(fileName);
			POIFSFileSystem fSystem = new POIFSFileSystem(fStream);
			HSSFWorkbook workBook = new HSSFWorkbook(fSystem);
			HSSFSheet mySheet = workBook.getSheetAt(0);

			for (int i = FR;; i++) {
				List<HSSFCell> cellHolder = new ArrayList<HSSFCell>();
				HSSFRow r = mySheet.getRow(i);
				if(r!=null){
					for (int j = FC; j <= LC; j++) {
						HSSFCell c = r.getCell(j);
						cellHolder.add(c);
					}
				}
				else{
					break;
				}				

				//insert into training_details
				sql="insert into gmf_training_detail(bensel_id,trn_name,trn_hour,trn_date,trn_year) values(?,?,?,?,?)";
				
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, (((HSSFCell) cellHolder.get(1)).toString()).toUpperCase());
				pstmt.setString(2, ((HSSFCell) cellHolder.get(7)).toString());
				hour=Float.parseFloat(((HSSFCell) cellHolder.get(9)).toString());
				pstmt.setFloat(3, hour);
				pstmt.setString(4, ((HSSFCell) cellHolder.get(8)).toString());
				pstmt.setString(5, trn_year);
				result=pstmt.executeUpdate();

				String bensyl_id=(((HSSFCell) cellHolder.get(1)).toString()).toUpperCase();	
				if(empSet.contains(bensyl_id)){
					//okay
				}
				else{
					empSet.add(bensyl_id);
					//call a method to add an employee if not in employee table
					String emp_name=((HSSFCell) cellHolder.get(2)).toString();
					addEmployee(emp_name,bensyl_id);
				}
			}

			//call method to update score board
			createScoreBoard(trn_year);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
		}
		return 1;
	}


	public int uploadYPWP(String trn_year,String fileName) throws IOException{
		
		Set<String> empSet;
		String status="":

		int result=0;
		Float hour=0.0f;
		String sql="";

		PreparedStatement pstmt=null;

		int FR=1;
		int FC = 0;
		int LC = 6;
		DBConnection dbCon=new DBConnection();


		try {
			empSet=getAllBensyl();
			deleteYPWPDetails(trn_year);
			System.out.println("start uploading ypwp details");

			FileInputStream fStream = new FileInputStream(fileName);
			POIFSFileSystem fSystem = new POIFSFileSystem(fStream);
			HSSFWorkbook workBook = new HSSFWorkbook(fSystem);
			HSSFSheet mySheet = workBook.getSheetAt(0);

			for (int i = FR;; i++) {
				List<HSSFCell> cellHolder = new ArrayList<HSSFCell>();
				HSSFRow r = mySheet.getRow(i);
				if(r!=null){
					for (int j = FC; j <= LC; j++) {
						HSSFCell c = r.getCell(j);
						cellHolder.add(c);
					}
				}
				else{
					break;
				}				

				//insert into ypwp details only if the status is done.
				
				status=((HSSFCell) cellHolder.get(5)).toString();

				if(status.equals("Done")){
					sql="insert into gmf_ypwp(bensel_id,practice,certification,ypwp_month,ypwp_year) values(?,?,?,?,?)";				
					pstmt=dbCon.getStatement(sql);
					pstmt.setString(1, (((HSSFCell) cellHolder.get(0)).toString()).toUpperCase());
					pstmt.setString(2, ((HSSFCell) cellHolder.get(2)).toString());
					pstmt.setString(3, ((HSSFCell) cellHolder.get(3)).toString());
					pstmt.setString(4, ((HSSFCell) cellHolder.get(6)).toString());
					pstmt.setString(5, trn_year);
					result=pstmt.executeUpdate();

					String bensyl_id=(((HSSFCell) cellHolder.get(0)).toString()).toUpperCase();	
					if(empSet.contains(bensyl_id)){
						//increase trophy count
						addTrophy(bensyl_id, trn_year);
					}
					else{
						empSet.add(bensyl_id);
						//call a method to add an employee if not in employee table
						String emp_name=((HSSFCell) cellHolder.get(4)).toString();
						addDetails(emp_name,bensyl_id,trn_year);
					}
				}
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
		}
		return 1;
		
	}
	

	public void addDetails(String emp_name, String bensyl_id, String trn_year) throws SQLException {

		PreparedStatement pstmt2=null, pstmt3=null;
		String sql1="", sql2="";
		int oe_id=0, result=0;
		DBConnection dbCon=new DBConnection();
		System.out.println("add employee if not already added");

		try {

			sql2="insert into gmf_employee(emp_name,status,bensyl_id) values(?,?,?)";

			pstmt3=dbCon.getStatement(sql2);
			pstmt3.setString(1, emp_name);
			pstmt3.setString(2, "notActive");
			pstmt3.setString(3, bensyl_id);
			result=pstmt3.executeUpdate();
	
			sql2="insert into gmf_scoreboard values(?,?,?,?,?,?,?,?)";

			pstmt2=dbCon.getStatement(sql2);
			pstmt2.setString(1, bensyl_id);
			pstmt2.setString(2, trn_year);
			pstmt2.setDouble(3, 0);
			pstmt2.setInt(4, 0);
			pstmt2.setInt(5, 0);
			pstmt2.setInt(6, 0);
			pstmt2.setInt(7, 1);
			pstmt2.setInt(8, 1);
			result=pstmt2.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			if(pstmt2!=null){
				pstmt2.close();
			}
			if(rs3!=null){
				rs3.close();
			}
			if(pstmt3!=null){
				pstmt3.close();
			}
		}

	}

	public void addEmployee(String emp_name, String bensyl_id) throws SQLException {

		PreparedStatement pstmt2=null, pstmt3=null;
		String sql1="", sql2="";
		int oe_id=0, result=0;
		DBConnection dbCon=new DBConnection();
		System.out.println("add employee if not already added");

		try {

			sql2="insert into gmf_employee(emp_name,status,bensyl_id) values(?,?,?)";

			pstmt3=dbCon.getStatement(sql2);
			pstmt3.setString(1, emp_name);
			pstmt3.setString(2, "notActive");
			pstmt3.setString(3, bensyl_id);
			result=pstmt3.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			if(pstmt2!=null){
				pstmt2.close();
			}
			if(rs3!=null){
				rs3.close();
			}
			if(pstmt3!=null){
				pstmt3.close();
			}
		}

	}

	public Set<String> getAllBensyl() throws SQLException{

		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String sql1="";
		Set<String> empSet=new TreeSet<String>();
		DBConnection dbCon=new DBConnection();

		try {

			sql1="select bensel_id from gmf_employee";

			pstmt=dbCon.getStatement(sql1);
			rs=pstmt.executeQuery();
			while(rs.next()){
				empSet.add(rs.getString("bensel_id"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
			rs.close();
		}
		return empSet;
	}

	public void createScoreBoard(String trn_year) {

		System.out.println("creating scoreboard");

		PreparedStatement pstmt=null, pstmt2=null, pstmt3=null;
		ResultSet rs=null, rs3=null, rs4=null;
		int trn_level=0, badge=0, trophy=0;

		String bensyl_id="";
		String sql="", sql2="", sql3="", sql4="", sql5="";
		DBConnection dbCon=new DBConnection();

		try{

			int result=0;
			float TotHour;
			sql="select distinct bensel_id from gmf_training_detail where trn_year=?"; 
				
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, trn_year);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				TotHour=0.0f;
				trn_level=0;
				badge=0;
				trophy=0;
				bensyl_id=rs.getString("bensyl_id");
				sql3="select trn_hour from gmf_training_detail where bensel_id=? and trn_year=?";

				pstmt3=dbCon.getStatement(sql3);
				pstmt3.setString(1, bensyl_id);
				pstmt3.setString(2, trn_year);
				rs3=pstmt3.executeQuery();
				while(rs3.next())
				{
					TotHour=(TotHour+(rs3.getFloat("training_hour")));
				}
				if(TotHour>=40){
					badge=1;					
				}
				if(TotHour<40){
					trn_level=0;
				}
				else if(TotHour>=40 && TotHour<150){
					trn_level=1;
				}
				else if(TotHour>=150 && TotHour<300){
					trn_level=2;
				}
				else if(TotHour>=300 && TotHour<500){
					trn_level=3;
				}
				else if(TotHour>=500){
					trophy=1;
					trn_level=4;
					int val=(int) (TotHour-500);
					val=val/250;
					badge+=val;
				}

				//check whether there is an entry for that employee in scoreboard
				sql4="select hours from gmf_scoreboard where trn_year=? and bensel_id=?";

				pstmt2=dbCon.getStatement(sql4);
				pstmt2.setString(1, trn_year);
				pstmt2.setString(2, bensyl_id);
				rs4=pstmt2.executeQuery();

				sql2="update gmf_scoreboard set hours=?,trn_level=?,badge=?,trn_trophy=? where trn_year=? and bensel_id=?";
				sql5="insert into gmf_scoreboard values(?,?,?,?,?,?,?,?)";
				if(rs4.next()){
							
					pstmt2=dbCon.getStatement(sql2);
					pstmt2.setFloat(1, TotHour);
					pstmt2.setInt(2,trn_level);
					pstmt2.setInt(3,badge);
					pstmt2.setInt(4,trophy);
					pstmt2.setString(5,trn_year);
					pstmt2.setString(6,bensyl_id);
					result=pstmt2.executeUpdate();

					//call to calculate total number of trophies for this employee.
					calculateTotalTrophy(String bensyl_id, int trn_year);

				}
				else{
							
					pstmt2=dbCon.getStatement(sql5);
					pstmt2.setString(1, bensyl_id);
					pstmt2.setString(2, trn_year);
					pstmt2.setDouble(3, TotHour);
					pstmt2.setInt(4, trn_level);
					pstmt2.setInt(5, badge);
					pstmt2.setInt(6, trophy);
					pstmt2.setInt(7, 0);
					pstmt2.setInt(8, trophy);
					result=pstmt2.executeUpdate();
					
				}				
			}

		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			try {
				dbCon.closeCon();
				if(pstmt!=null){
					pstmt.close();
				}
				if(pstmt2!=null){
					pstmt2.close();
				}
				if(pstmt3!=null){
					pstmt2.close();
				}
				if(rs!=null){
					rs.close();
				}
				if(rs3!=null){
					rs3.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void deleteTables(String trn_year) throws SQLException{

		System.out.println("deleting tables");
		PreparedStatement pstmt=null;
		String sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();

		try {
			sql="delete from gmf_training_detail where trn_year=?";

			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, trn_year);
			result=pstmt.executeUpdate();		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
		}
	}

	//delete rows from YPWP

	public void deleteYPWPDetails(String trn_year) throws SQLException{

		System.out.println("deleting YPWP details");
		PreparedStatement pstmt=null;
		String sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();

		try {
			sql="delete from gmf_ypwp where trn_year=?";

			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, trn_year);
			result=pstmt.executeUpdate();		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
		}
	}

	//increase trophy count after one YPWP
	
	public void addTrophy(String bensyl_id, String trn_year){

		PreparedStatement pstmt=null;
		String sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();

		try {
			sql="update gmf_scoreboard set tot_trophy=(tot_trophy+1), ypwp_trophy=(ypwp_trophy+1) where bensel_id=? and trn_year=?";

			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_id);
			pstmt.setString(2, trn_year);
			result=pstmt.executeUpdate();		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
		}
	}



	//Calculate total number of trophies after updating the scoreboard table for a particular bensel ID nad training year

	public void calculateTotalTrophy(String bensyl_id, int trn_year){

		PreparedStatement pstmt=null;
		String sql="";
		int result=0;
		DBConnection dbCon=new DBConnection();

		try {
			sql="update gmf_scoreboard set tot_trophy=(trn_trophy+ypwp_trophy) where bensel_id=? and trn_year=?";

			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_id);
			pstmt.setString(2, trn_year);
			result=pstmt.executeUpdate();		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			dbCon.closeCon();
			pstmt.close();
		}
	}

}
