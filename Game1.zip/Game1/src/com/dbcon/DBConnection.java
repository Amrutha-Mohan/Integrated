package com.dbcon;

import java.sql.*;

public class DBConnection {	
	
	Connection con;
	PreparedStatement pstmt;
	int ok;
	
	public DBConnection() {
		super();
		con=null;
		pstmt=null;
		ok=0;
	}

	public void init()
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver"); //loading oracle drivers. This differs for database servers
			con = DriverManager.getConnection("jdbc:oracle:thin:@sla18326:1521:ukahp1d", "AZT_TRN", "Azt_trn1#"); //attempting to connect to oracle database
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public PreparedStatement getStatement(String sql){
		try {
			init();
			pstmt= con.prepareStatement(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pstmt;
	}
	
	public void closeCon(){
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
