package com.beans;

public class TrainingDetail {
	
	private int trn_id;
	private String bensel_id;
	private String trn_year;
	private String trn_name;
	private float trn_hour;
	private String trn_date;
	
	public TrainingDetail() {
		super();
	}

	public TrainingDetail(int trn_id, String bensel_id, String trn_year, String trn_name, float trn_hour,
			String trn_date) {
		super();
		this.trn_id = trn_id;
		this.bensel_id = bensel_id;
		this.trn_year = trn_year;
		this.trn_name = trn_name;
		this.trn_hour = trn_hour;
		this.trn_date = trn_date;
	}

	public int getTrn_id() {
		return trn_id;
	}

	public void setTrn_id(int trn_id) {
		this.trn_id = trn_id;
	}

	public String getBensel_id() {
		return bensel_id;
	}

	public void setBensel_id(String bensel_id) {
		this.bensel_id = bensel_id;
	}

	public String getTrn_year() {
		return trn_year;
	}

	public void setTrn_year(String trn_year) {
		this.trn_year = trn_year;
	}

	public String getTrn_name() {
		return trn_name;
	}

	public void setTrn_name(String trn_name) {
		this.trn_name = trn_name;
	}

	public float getTrn_hour() {
		return trn_hour;
	}

	public void setTrn_hour(float trn_hour) {
		this.trn_hour = trn_hour;
	}

	public String getTrn_date() {
		return trn_date;
	}

	public void setTrn_date(String trn_date) {
		this.trn_date = trn_date;
	}
	
}
