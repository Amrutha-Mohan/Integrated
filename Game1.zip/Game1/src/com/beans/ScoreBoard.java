package com.beans;

public class ScoreBoard {

	private String bensel_id;
	private int trn_year;
	private float hours;
	private int trn_level;
	private int badge;
	private int trn_trophy;
	private int ypwp_trophy;
	private int tot_trophy;

	public ScoreBoard() {
		super();
	}

	public ScoreBoard(String bensel_id, int trn_year, float hours, int trn_level, int badge, int trn_trophy,
			int ypwp_trophy, int tot_trophy) {
		super();
		this.bensel_id = bensel_id;
		this.trn_year = trn_year;
		this.hours = hours;
		this.trn_level = trn_level;
		this.badge = badge;
		this.trn_trophy = trn_trophy;
		this.ypwp_trophy = ypwp_trophy;
		this.tot_trophy = tot_trophy;
	}

	public String getBensel_id() {
		return bensel_id;
	}

	public void setBensel_id(String bensel_id) {
		this.bensel_id = bensel_id;
	}

	public int getTrn_year() {
		return trn_year;
	}

	public void setTrn_year(int trn_year) {
		this.trn_year = trn_year;
	}

	public float getHours() {
		return hours;
	}

	public void setHours(float hours) {
		this.hours = hours;
	}

	public int getTrn_level() {
		return trn_level;
	}

	public void setTrn_level(int trn_level) {
		this.trn_level = trn_level;
	}

	public int getBadge() {
		return badge;
	}

	public void setBadge(int badge) {
		this.badge = badge;
	}

	public int getTrn_trophy() {
		return trn_trophy;
	}

	public void setTrn_trophy(int trn_trophy) {
		this.trn_trophy = trn_trophy;
	}

	public int getYpwp_trophy() {
		return ypwp_trophy;
	}

	public void setYpwp_trophy(int ypwp_trophy) {
		this.ypwp_trophy = ypwp_trophy;
	}

	public int getTot_trophy() {
		return tot_trophy;
	}

	public void setTot_trophy(int tot_trophy) {
		this.tot_trophy = tot_trophy;
	}
	
}
