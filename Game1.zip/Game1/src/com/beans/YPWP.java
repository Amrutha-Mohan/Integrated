package com.beans;

public class YPWP {
	
	private int YPWP_id;
	private String bensel_id;
	private String practice;
	private String certification;
	private String ypwp_month;
	private String ypwp_year;
	
	public YPWP() {
		super();
	}

	public YPWP(int yPWP_id, String bensel_id, String practice, String certification, String ypwp_month,
			String ypwp_year) {
		super();
		YPWP_id = yPWP_id;
		this.bensel_id = bensel_id;
		this.practice = practice;
		this.certification = certification;
		this.ypwp_month = ypwp_month;
		this.ypwp_year = ypwp_year;
	}

	public int getYPWP_id() {
		return YPWP_id;
	}

	public void setYPWP_id(int yPWP_id) {
		YPWP_id = yPWP_id;
	}

	public String getBensel_id() {
		return bensel_id;
	}

	public void setBensel_id(String bensel_id) {
		this.bensel_id = bensel_id;
	}

	public String getPractice() {
		return practice;
	}

	public void setPractice(String practice) {
		this.practice = practice;
	}

	public String getCertification() {
		return certification;
	}

	public void setCertification(String certification) {
		this.certification = certification;
	}

	public String getYpwp_month() {
		return ypwp_month;
	}

	public void setYpwp_month(String ypwp_month) {
		this.ypwp_month = ypwp_month;
	}

	public String getYpwp_year() {
		return ypwp_year;
	}

	public void setYpwp_year(String ypwp_year) {
		this.ypwp_year = ypwp_year;
	}
	
}
