package com.beans;

public class YPWP {

	private int YPWP_id;
	private String bensel_id;
	private String practice;
	private String certification;
	private String ypwp_month;
	private String ypwp_year;
	
	public YPWP() {
		super();
	}

	//generate parametrised constructor and getters and setters
		
}
