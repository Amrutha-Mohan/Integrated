package com.beans;

public class Employee {

	private String bensel_id;
	private String emp_name;
	private String emp_email;
	private String password;
	private String status;
	private String staff_id;
	
	public Employee() {
		super();
	}
	
	public Employee(String bensel_id, String emp_name, String emp_email, String password, String status,
			String staff_id) {
		super();
		this.bensel_id = bensel_id;
		this.emp_name = emp_name;
		this.emp_email = emp_email;
		this.password = password;
		this.status = status;
		this.staff_id = staff_id;
	}

	public Employee(String bensel_id, String emp_name, String emp_email, String status) {
		super();
		this.bensel_id = bensel_id;
		this.emp_name = emp_name;
		this.emp_email = emp_email;
		this.status = status;
	}

	public Employee(String bensel_id, String password) {
		this.password = password;
		this.bensel_id = bensel_id;
	}

	public String getBensel_id() {
		return bensel_id;
	}

	public void setBensel_id(String bensel_id) {
		this.bensel_id = bensel_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getEmp_email() {
		return emp_email;
	}

	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStaff_id() {
		return staff_id;
	}

	public void setStaff_id(String staff_id) {
		this.staff_id = staff_id;
	}
	
}

